
# Step 1: Create a list of 400 workers dynamically
worker_list <- list()
num_workers <- 400

# Gender choices
genders <- c("Male", "Female")

# Step 2: Generate worker details dynamically
for (i in 1:num_workers) {{
  worker <- list(
    id = paste("Worker", i, sep="-"),
    salary = sample(5000:35000, 1),
    gender = sample(genders, 1)
  )
  worker_list[[i]] <- worker
}}

# Step 3: Payment slip generation function
generate_payment_slip <- function(worker) {{
  tryCatch({{
    employee_level <- "Unknown"
    
    # Step 4: Conditional statements to determine employee level
    if (worker$salary > 10000 && worker$salary < 20000) {{
      employee_level <- "A1"
    }} else if (worker$salary > 7500 && worker$salary < 30000 && worker$gender == "Female") {{
      employee_level <- "A5-F"
    }}
    
    # Simulate the generation of payment slips
    cat("Generating payment slip for", worker$id, ":
")
    cat("Salary:", worker$salary, "Gender:", worker$gender, "Employee Level:", employee_level, "
")
    cat(rep("-", 40), "
", sep="")
    
  }}, error = function(e) {{
    cat("Error processing payment slip for", worker$id, ":", e$message, "
")
  }})
}}

# Step 5: Process all workers
for (worker in worker_list) {{
  generate_payment_slip(worker)
}}
